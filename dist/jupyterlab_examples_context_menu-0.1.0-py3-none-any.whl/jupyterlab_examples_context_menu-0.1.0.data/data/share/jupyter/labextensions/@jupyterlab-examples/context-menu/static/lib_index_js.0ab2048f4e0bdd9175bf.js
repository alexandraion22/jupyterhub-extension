"use strict";
(self["webpackChunk_jupyterlab_examples_context_menu"] = self["webpackChunk_jupyterlab_examples_context_menu"] || []).push([["lib_index_js"],{

/***/ "./lib/api.js"
/*!********************!*\
  !*** ./lib/api.js ***!
  \********************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   acceptShare: () => (/* binding */ acceptShare),
/* harmony export */   buildShareLink: () => (/* binding */ buildShareLink),
/* harmony export */   fetchApiToken: () => (/* binding */ fetchApiToken),
/* harmony export */   fetchMe: () => (/* binding */ fetchMe),
/* harmony export */   fetchMyShares: () => (/* binding */ fetchMyShares),
/* harmony export */   fetchPermissions: () => (/* binding */ fetchPermissions),
/* harmony export */   fetchPermissionsByVolume: () => (/* binding */ fetchPermissionsByVolume),
/* harmony export */   revokeAccess: () => (/* binding */ revokeAccess),
/* harmony export */   setGeneralAccess: () => (/* binding */ setGeneralAccess),
/* harmony export */   shareFolder: () => (/* binding */ shareFolder)
/* harmony export */ });
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_0__);

const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_0__.ServerConnection.makeSettings();
const jsonError = async (response, fallback) => {
    var _a;
    try {
        const data = await response.json();
        return ((_a = data === null || data === void 0 ? void 0 : data.error) === null || _a === void 0 ? void 0 : _a.message) || (data === null || data === void 0 ? void 0 : data.error) || fallback;
    }
    catch (_b) {
        return fallback;
    }
};
const request = async (path, init, token) => {
    const headers = new Headers(init.headers);
    headers.set('Content-Type', 'application/json');
    if (token) {
        headers.set('Authorization', `Bearer ${token}`);
    }
    const response = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_0__.ServerConnection.makeRequest(`${settings.baseUrl}${path}`, { ...init, headers }, settings);
    if (!response.ok) {
        throw new Error(await jsonError(response, response.statusText));
    }
    return (await response.json());
};
const fetchApiToken = async () => {
    var _a;
    try {
        const response = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_0__.ServerConnection.makeRequest(`${settings.baseUrl}jlab-examples/google-token`, {}, settings);
        if (!response.ok) {
            console.error('Failed to fetch API token:', response.statusText);
            return null;
        }
        const data = (await response.json());
        return (_a = data.token) !== null && _a !== void 0 ? _a : null;
    }
    catch (error) {
        console.error('Error fetching API token:', error);
        return null;
    }
};
const shareFolder = (req, token) => request('jlab-examples/share', {
    method: 'POST',
    body: JSON.stringify({
        directory_name: req.directoryName,
        recipients: req.recipients,
        general_access: req.generalAccess,
        link_access_level: req.linkAccessLevel,
        token
    })
});
const fetchPermissions = (directoryName, token) => request(`jlab-examples/permissions?directory=${encodeURIComponent(directoryName)}`, { method: 'GET' }, token);
const fetchPermissionsByVolume = (volumeName, token) => request(`jlab-examples/permissions?volume_name=${encodeURIComponent(volumeName)}`, { method: 'GET' }, token);
const revokeAccess = (volumeName, userEmail, token) => request('jlab-examples/permissions', {
    method: 'DELETE',
    body: JSON.stringify({
        volume_name: volumeName,
        user_email: userEmail,
        token
    })
});
const setGeneralAccess = (volumeName, generalAccess, linkAccessLevel, token) => request(`jlab-examples/general-access/${encodeURIComponent(volumeName)}`, {
    method: 'PUT',
    body: JSON.stringify({
        general_access: generalAccess,
        link_access_level: linkAccessLevel,
        token
    })
});
const acceptShare = (volumeName, token) => request(`jlab-examples/accept/${encodeURIComponent(volumeName)}`, { method: 'POST' }, token);
const fetchMyShares = (token) => request('jlab-examples/my-shares', { method: 'GET' }, token);
const fetchMe = async () => {
    try {
        const response = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_0__.ServerConnection.makeRequest(`${settings.baseUrl}jlab-examples/me`, {}, settings);
        if (!response.ok) {
            return null;
        }
        return (await response.json());
    }
    catch (_a) {
        return null;
    }
};
const buildShareLink = (volumeName) => {
    // Use user-redirect so any authenticated user lands in their own lab pod;
    // the extension picks up ?share-link=<volume_name> on startup and accepts.
    const origin = window.location.origin;
    return `${origin}/hub/user-redirect/lab?share-link=${encodeURIComponent(volumeName)}`;
};


/***/ },

/***/ "./lib/dialogs/ShareDialog.js"
/*!************************************!*\
  !*** ./lib/dialogs/ShareDialog.js ***!
  \************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ShareDialogBody: () => (/* binding */ ShareDialogBody)
/* harmony export */ });
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_0__);

const EMAIL_RE = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
class ShareDialogBody extends _lumino_widgets__WEBPACK_IMPORTED_MODULE_0__.Widget {
    constructor(folderName, ownerDomain, initialGeneralAccess = 'restricted', initialLinkAccess = 'read', existingPermissions = [], ownerEmail = '', controller) {
        super({ node: document.createElement('div') });
        this.folderName = folderName;
        this.ownerDomain = ownerDomain;
        this.ownerEmail = ownerEmail;
        this.controller = controller;
        this.rows = [];
        this.node.style.minWidth = '500px';
        this.node.style.fontSize = '13px';
        this.peopleHeading = document.createElement('div');
        this.peopleHeading.style.fontWeight = '600';
        this.peopleHeading.style.marginBottom = '6px';
        this.node.appendChild(this.peopleHeading);
        this.chipsContainer = document.createElement('div');
        this.chipsContainer.style.display = 'flex';
        this.chipsContainer.style.flexDirection = 'column';
        this.chipsContainer.style.gap = '4px';
        this.chipsContainer.style.marginBottom = '10px';
        this.chipsContainer.style.maxHeight = '180px';
        this.chipsContainer.style.overflowY = 'auto';
        this.node.appendChild(this.chipsContainer);
        if (ownerEmail) {
            this.renderOwnerChip(ownerEmail);
        }
        for (const p of existingPermissions) {
            if (p.user_email === ownerEmail) {
                continue;
            }
            this.addRow(p.user_email, p.access_level === 'write' ? 'editor' : 'viewer');
        }
        this.updatePeopleHeading();
        const addHeading = document.createElement('div');
        addHeading.textContent = 'Add people';
        addHeading.style.fontWeight = '600';
        addHeading.style.margin = '10px 0 6px';
        this.node.appendChild(addHeading);
        const addRow = document.createElement('div');
        addRow.style.display = 'flex';
        addRow.style.gap = '6px';
        addRow.style.marginBottom = '8px';
        this.emailInput = document.createElement('input');
        this.emailInput.type = 'email';
        this.emailInput.placeholder = 'Email address';
        this.emailInput.style.flex = '1';
        this.emailInput.style.padding = '4px 6px';
        this.emailInput.addEventListener('keydown', e => {
            if (e.key === 'Enter' || e.key === ',') {
                e.preventDefault();
                void this.commitCurrentInput();
            }
        });
        this.addRoleSelect = buildRoleSelect('viewer');
        this.addBtn = document.createElement('button');
        this.addBtn.textContent = 'Add';
        this.addBtn.style.cursor = 'pointer';
        this.addBtn.addEventListener('click', e => {
            e.preventDefault();
            void this.commitCurrentInput();
        });
        addRow.appendChild(this.emailInput);
        addRow.appendChild(this.addRoleSelect);
        addRow.appendChild(this.addBtn);
        this.node.appendChild(addRow);
        this.errorSpan = document.createElement('span');
        this.errorSpan.style.color = '#e74c3c';
        this.errorSpan.style.fontSize = '12px';
        this.errorSpan.style.display = 'none';
        this.errorSpan.style.marginBottom = '8px';
        this.node.appendChild(this.errorSpan);
        this.statusSpan = document.createElement('span');
        this.statusSpan.style.color = '#888';
        this.statusSpan.style.fontSize = '12px';
        this.statusSpan.style.display = 'none';
        this.statusSpan.style.marginBottom = '8px';
        this.node.appendChild(this.statusSpan);
        const divider = document.createElement('hr');
        divider.style.border = 'none';
        divider.style.borderTop = '1px solid #ddd';
        divider.style.margin = '8px 0 12px';
        this.node.appendChild(divider);
        const gaHeading = document.createElement('div');
        gaHeading.textContent = 'General access';
        gaHeading.style.fontWeight = '600';
        gaHeading.style.marginBottom = '6px';
        this.node.appendChild(gaHeading);
        const gaRow = document.createElement('div');
        gaRow.style.display = 'flex';
        gaRow.style.gap = '6px';
        gaRow.style.alignItems = 'center';
        gaRow.style.marginBottom = '6px';
        this.generalAccessSelect = document.createElement('select');
        addOption(this.generalAccessSelect, 'restricted', 'Restricted');
        addOption(this.generalAccessSelect, 'domain', ownerDomain ? `Anyone at ${ownerDomain}` : 'Anyone in your domain');
        this.generalAccessSelect.value = initialGeneralAccess;
        this.generalAccessSelect.addEventListener('change', () => {
            void this.commitGeneralAccess();
        });
        this.linkRoleSelect = buildRoleSelect(initialLinkAccess === 'write' ? 'editor' : 'viewer');
        this.linkRoleSelect.addEventListener('change', () => {
            void this.commitGeneralAccess();
        });
        gaRow.appendChild(this.generalAccessSelect);
        gaRow.appendChild(this.linkRoleSelect);
        this.node.appendChild(gaRow);
        this.linkHint = document.createElement('span');
        this.linkHint.style.fontSize = '12px';
        this.linkHint.style.color = '#666';
        this.linkHint.style.display = 'block';
        this.linkHint.style.marginBottom = '6px';
        this.node.appendChild(this.linkHint);
        this.copyLinkBtn = document.createElement('button');
        this.copyLinkBtn.textContent = 'Copy link';
        this.copyLinkBtn.style.cursor = 'pointer';
        this.copyLinkBtn.style.padding = '3px 10px';
        this.copyLinkBtn.addEventListener('click', e => {
            e.preventDefault();
            void this.copyLink();
        });
        this.node.appendChild(this.copyLinkBtn);
        this.updateLinkState();
    }
    renderOwnerChip(email) {
        const row = document.createElement('div');
        row.style.display = 'flex';
        row.style.alignItems = 'center';
        row.style.gap = '8px';
        row.style.padding = '3px 6px';
        row.style.background = '#f5f5f5';
        row.style.borderRadius = '4px';
        const emailSpan = document.createElement('span');
        emailSpan.textContent = `${email} (owner)`;
        emailSpan.style.flex = '1';
        emailSpan.style.color = '#666';
        emailSpan.style.fontStyle = 'italic';
        row.appendChild(emailSpan);
        this.chipsContainer.appendChild(row);
    }
    updatePeopleHeading() {
        const activeCount = this.rows.length + 1; // +1 for owner
        this.peopleHeading.textContent = `People with access (${activeCount})`;
    }
    setBusy(msg) {
        if (msg === null) {
            this.statusSpan.style.display = 'none';
            return;
        }
        this.statusSpan.textContent = msg;
        this.statusSpan.style.display = 'block';
    }
    updateLinkState() {
        var _a, _b;
        const domain = this.generalAccessSelect.value === 'domain';
        this.linkRoleSelect.disabled = !domain;
        const link = (_b = (_a = this.controller) === null || _a === void 0 ? void 0 : _a.currentShareLink()) !== null && _b !== void 0 ? _b : null;
        this.copyLinkBtn.disabled = !link;
        if (!link) {
            this.linkHint.textContent =
                'Link becomes available once the folder has been shared with at least one recipient or domain access is enabled.';
        }
        else if (domain) {
            this.linkHint.textContent = `Anyone at ${this.ownerDomain || 'your domain'} with this link can access “${this.folderName}”.`;
        }
        else {
            this.linkHint.textContent =
                'Only people explicitly added above can use this link.';
        }
    }
    async commitCurrentInput() {
        const email = this.emailInput.value.trim().replace(/,$/, '');
        if (!email) {
            return;
        }
        if (!EMAIL_RE.test(email)) {
            this.showError(`“${email}” is not a valid email.`);
            return;
        }
        if (email.toLowerCase() === this.ownerEmail.toLowerCase()) {
            this.showError('You already own this folder.');
            return;
        }
        if (this.rows.some(r => r.email.toLowerCase() === email.toLowerCase())) {
            this.showError(`${email} is already in the list.`);
            return;
        }
        const role = this.addRoleSelect.value;
        this.hideError();
        if (!this.controller) {
            return;
        }
        // Optimistic: render immediately. Revert on failure.
        const row = this.addRow(email, role);
        this.emailInput.value = '';
        this.emailInput.focus();
        this.updatePeopleHeading();
        this.setBusy(`Sharing with ${email}…`);
        try {
            await this.controller.upsertRecipient(email, role);
            this.setBusy(null);
            this.updateLinkState();
        }
        catch (err) {
            this.removeRowNode(row);
            this.updatePeopleHeading();
            this.setBusy(null);
            this.showError(err instanceof Error ? err.message : 'Failed to share with this user.');
        }
    }
    addRow(email, role) {
        const container = document.createElement('div');
        container.style.display = 'flex';
        container.style.alignItems = 'center';
        container.style.gap = '8px';
        container.style.padding = '3px 6px';
        container.style.background = '#eef5ff';
        container.style.borderRadius = '4px';
        const emailSpan = document.createElement('span');
        emailSpan.textContent = email;
        emailSpan.style.flex = '1';
        emailSpan.style.overflow = 'hidden';
        emailSpan.style.textOverflow = 'ellipsis';
        const roleSelect = buildRoleSelect(role);
        const removeBtn = document.createElement('button');
        removeBtn.textContent = '×';
        removeBtn.title = 'Remove';
        removeBtn.style.cursor = 'pointer';
        removeBtn.style.border = 'none';
        removeBtn.style.background = 'transparent';
        removeBtn.style.fontSize = '16px';
        container.appendChild(emailSpan);
        container.appendChild(roleSelect);
        container.appendChild(removeBtn);
        this.chipsContainer.appendChild(container);
        const row = { container, email, role, roleSelect, removeBtn };
        this.rows.push(row);
        roleSelect.addEventListener('change', async () => {
            const prev = row.role;
            const next = roleSelect.value;
            if (prev === next || !this.controller) {
                return;
            }
            this.setBusy(`Updating ${email}…`);
            try {
                await this.controller.upsertRecipient(email, next);
                row.role = next;
                this.setBusy(null);
            }
            catch (err) {
                roleSelect.value = prev;
                this.setBusy(null);
                this.showError(err instanceof Error
                    ? err.message
                    : `Failed to update ${email}'s access.`);
            }
        });
        removeBtn.addEventListener('click', async () => {
            if (!this.controller) {
                this.removeRowNode(row);
                this.updatePeopleHeading();
                return;
            }
            const prev = removeBtn.textContent;
            removeBtn.textContent = '…';
            removeBtn.disabled = true;
            roleSelect.disabled = true;
            this.setBusy(`Removing ${email}…`);
            try {
                await this.controller.revokeRecipient(email);
                this.removeRowNode(row);
                this.updatePeopleHeading();
                this.setBusy(null);
            }
            catch (err) {
                removeBtn.textContent = prev;
                removeBtn.disabled = false;
                roleSelect.disabled = false;
                this.setBusy(null);
                this.showError(err instanceof Error ? err.message : `Failed to remove ${email}.`);
            }
        });
        return row;
    }
    removeRowNode(row) {
        this.rows = this.rows.filter(r => r !== row);
        row.container.remove();
    }
    async commitGeneralAccess() {
        if (!this.controller) {
            return;
        }
        const mode = this.generalAccessSelect.value;
        const linkRole = this.linkRoleSelect.value;
        const level = linkRole === 'editor' ? 'write' : 'read';
        this.setBusy('Updating general access…');
        try {
            await this.controller.setGeneralAccess(mode, level);
            this.setBusy(null);
            this.updateLinkState();
        }
        catch (err) {
            this.setBusy(null);
            this.showError(err instanceof Error
                ? err.message
                : 'Failed to update general access.');
        }
    }
    async copyLink() {
        var _a, _b;
        const link = (_b = (_a = this.controller) === null || _a === void 0 ? void 0 : _a.currentShareLink()) !== null && _b !== void 0 ? _b : null;
        if (!link) {
            return;
        }
        const ok = await tryCopyToClipboard(link);
        if (ok) {
            const original = this.copyLinkBtn.textContent;
            this.copyLinkBtn.textContent = 'Copied!';
            setTimeout(() => {
                this.copyLinkBtn.textContent = original;
            }, 1500);
        }
        else {
            this.showError(`Copy failed. The link is: ${link} — select and copy it manually.`);
        }
    }
    showError(msg) {
        this.errorSpan.textContent = msg;
        this.errorSpan.style.display = 'block';
        setTimeout(() => this.hideError(), 5000);
    }
    hideError() {
        this.errorSpan.style.display = 'none';
    }
    /**
     * Re-render the link button/hint — used after the controller mutates its
     * internal state (e.g. first shareFolder call populates the share link).
     */
    refreshLinkState() {
        this.updateLinkState();
    }
}
function buildRoleSelect(initial) {
    const select = document.createElement('select');
    addOption(select, 'viewer', 'Viewer');
    addOption(select, 'editor', 'Editor');
    select.value = initial;
    return select;
}
function addOption(select, value, label) {
    const opt = document.createElement('option');
    opt.value = value;
    opt.textContent = label;
    select.appendChild(opt);
}
async function tryCopyToClipboard(text) {
    try {
        if (navigator.clipboard && window.isSecureContext) {
            await navigator.clipboard.writeText(text);
            return true;
        }
    }
    catch (_a) {
        // fall through
    }
    try {
        const ta = document.createElement('textarea');
        ta.value = text;
        ta.style.position = 'fixed';
        ta.style.left = '-9999px';
        document.body.appendChild(ta);
        ta.focus();
        ta.select();
        const ok = document.execCommand('copy');
        document.body.removeChild(ta);
        return ok;
    }
    catch (_b) {
        return false;
    }
}


/***/ },

/***/ "./lib/index.js"
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/filebrowser */ "webpack/sharing/consume/default/@jupyterlab/filebrowser");
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./api */ "./lib/api.js");
/* harmony import */ var _dialogs_ShareDialog__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./dialogs/ShareDialog */ "./lib/dialogs/ShareDialog.js");
/* harmony import */ var _widgets_SharedWithMePanel__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./widgets/SharedWithMePanel */ "./lib/widgets/SharedWithMePanel.js");







const SHARE_LINK_PARAM = 'share-link';
function isInManagedSharedTree(item) {
    if (!item) {
        return false;
    }
    const path = item.path.replace(/^\/+|\/+$/g, '');
    return path === 'shared' || path.startsWith('shared/');
}
const extension = {
    id: '@jupyterlab-examples/context-menu:plugin',
    description: 'JupyterLab extension for folder sharing and permissions management.',
    autoStart: true,
    requires: [_jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_0__.IFileBrowserFactory],
    activate: (app, factory) => {
        const getSelectedItem = () => { var _a, _b; return (_b = (_a = factory.tracker.currentWidget) === null || _a === void 0 ? void 0 : _a.selectedItems().next()) === null || _b === void 0 ? void 0 : _b.value; };
        const isDirectory = (item) => (item === null || item === void 0 ? void 0 : item.type) === 'directory';
        // --- Shared-with-me sidebar ---
        const sharesPanel = new _widgets_SharedWithMePanel__WEBPACK_IMPORTED_MODULE_6__.SharedWithMePanel();
        app.shell.add(sharesPanel, 'left', { rank: 900 });
        let ownerDomain = '';
        let myEmail = '';
        let myShares = [];
        const refreshShares = async () => {
            const token = await (0,_api__WEBPACK_IMPORTED_MODULE_4__.fetchApiToken)();
            if (!token) {
                sharesPanel.setError('Sign-in token unavailable.');
                return;
            }
            try {
                const data = await (0,_api__WEBPACK_IMPORTED_MODULE_4__.fetchMyShares)(token);
                myShares = data.shares;
                sharesPanel.setShares(myShares);
                applyShareIndicators();
            }
            catch (err) {
                sharesPanel.setError(err instanceof Error ? err.message : 'Failed to load shares.');
            }
        };
        sharesPanel.refreshRequested.connect(() => {
            void refreshShares();
        });
        sharesPanel.openRequested.connect(async (_, { share }) => {
            const path = share.is_owner
                ? share.display_name
                : `shared/${share.display_name}`;
            try {
                await app.serviceManager.contents.get(path, { content: false });
            }
            catch (_a) {
                await promptServerRestart(share.display_name);
                return;
            }
            try {
                await app.commands.execute('filebrowser:open-path', { path });
            }
            catch (err) {
                void (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.showErrorMessage)('Could not open folder', err instanceof Error ? err.message : String(err));
            }
        });
        // --- Share Folder command ---
        app.commands.addCommand('jlab-examples/context-menu:share', {
            label: 'Share Folder',
            caption: 'Share this folder and manage access',
            icon: _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.buildIcon,
            isEnabled: () => {
                const item = getSelectedItem();
                return isDirectory(item) && !isInManagedSharedTree(item);
            },
            isVisible: () => {
                const item = getSelectedItem();
                return isDirectory(item) && !isInManagedSharedTree(item);
            },
            execute: async () => {
                const file = getSelectedItem();
                if (!file || !isDirectory(file) || isInManagedSharedTree(file)) {
                    return;
                }
                const token = await (0,_api__WEBPACK_IMPORTED_MODULE_4__.fetchApiToken)();
                if (!token) {
                    void (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.showErrorMessage)('Authentication Error', 'Session expired or token unavailable. Please restart your server.');
                    return;
                }
                // Snapshot of the share (if any) as it exists at dialog-open time.
                // As the user mutates things the controller refreshes these.
                let volumeName = null;
                let generalAccess = 'restricted';
                let linkAccessLevel = 'read';
                let existingPermissions = [];
                const existing = myShares.find(s => s.is_owner && s.display_name === file.name);
                if (existing) {
                    volumeName = existing.volume_name;
                    generalAccess = existing.general_access;
                    linkAccessLevel = existing.link_access_level;
                    try {
                        const perms = await (0,_api__WEBPACK_IMPORTED_MODULE_4__.fetchPermissions)(file.name, token);
                        existingPermissions = perms.permissions;
                    }
                    catch (err) {
                        console.warn('Could not load existing permissions:', err);
                    }
                }
                // Declared before controller so the controller can call
                // dialogBody.refreshLinkState() after state changes.
                let dialogBody;
                const controller = {
                    upsertRecipient: async (email, role) => {
                        const response = await (0,_api__WEBPACK_IMPORTED_MODULE_4__.shareFolder)({
                            directoryName: file.name,
                            recipients: [{ email, role }],
                            generalAccess,
                            linkAccessLevel
                        }, token);
                        volumeName = response.volume_name;
                        generalAccess = response.general_access;
                        linkAccessLevel = response.link_access_level;
                        await refreshShares();
                        dialogBody.refreshLinkState();
                        return (0,_api__WEBPACK_IMPORTED_MODULE_4__.buildShareLink)(volumeName);
                    },
                    revokeRecipient: async (email) => {
                        if (!volumeName) {
                            return;
                        }
                        await (0,_api__WEBPACK_IMPORTED_MODULE_4__.revokeAccess)(volumeName, email, token);
                        await refreshShares();
                    },
                    setGeneralAccess: async (mode, level) => {
                        const response = await (0,_api__WEBPACK_IMPORTED_MODULE_4__.shareFolder)({
                            directoryName: file.name,
                            recipients: [],
                            generalAccess: mode,
                            linkAccessLevel: level
                        }, token);
                        volumeName = response.volume_name;
                        generalAccess = response.general_access;
                        linkAccessLevel = response.link_access_level;
                        await refreshShares();
                        dialogBody.refreshLinkState();
                        return (0,_api__WEBPACK_IMPORTED_MODULE_4__.buildShareLink)(volumeName);
                    },
                    currentShareLink: () => volumeName ? (0,_api__WEBPACK_IMPORTED_MODULE_4__.buildShareLink)(volumeName) : null
                };
                dialogBody = new _dialogs_ShareDialog__WEBPACK_IMPORTED_MODULE_5__.ShareDialogBody(file.name, ownerDomain, generalAccess, linkAccessLevel, existingPermissions, myEmail, controller);
                await (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.showDialog)({
                    title: `Share "${file.name}"`,
                    body: dialogBody,
                    buttons: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Dialog.okButton({ label: 'Done' })]
                });
            }
        });
        // --- Share indicator in file browser ---
        const applyShareIndicators = () => {
            const widget = factory.tracker.currentWidget;
            if (!widget) {
                return;
            }
            const ownedNames = new Set(myShares.filter(s => s.is_owner).map(s => s.display_name));
            const currentPath = widget.model.path;
            const items = widget.node.querySelectorAll('.jp-DirListing-item');
            items.forEach(item => {
                var _a;
                const textEl = item.querySelector('.jp-DirListing-itemText');
                const name = (_a = textEl === null || textEl === void 0 ? void 0 : textEl.textContent) === null || _a === void 0 ? void 0 : _a.trim();
                const shouldDecorate = !!name && currentPath === '' && ownedNames.has(name);
                item.classList.toggle('jp-shared-folder', shouldDecorate);
            });
        };
        const attachBrowserSignals = () => {
            const widget = factory.tracker.currentWidget;
            if (!widget) {
                return;
            }
            widget.model.pathChanged.connect(applyShareIndicators);
            widget.model.refreshed.connect(applyShareIndicators);
            applyShareIndicators();
        };
        factory.tracker.currentChanged.connect(attachBrowserSignals);
        attachBrowserSignals();
        // --- Auto-accept ?share-link= on boot ---
        const handleShareLink = async () => {
            var _a;
            const params = new URLSearchParams(window.location.search);
            const volume = params.get(SHARE_LINK_PARAM);
            if (!volume) {
                return;
            }
            const token = await (0,_api__WEBPACK_IMPORTED_MODULE_4__.fetchApiToken)();
            if (!token) {
                return;
            }
            try {
                const res = await (0,_api__WEBPACK_IMPORTED_MODULE_4__.acceptShare)(volume, token);
                await refreshShares();
                const alreadyMember = res
                    .already_member;
                if (alreadyMember) {
                    void (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.showDialog)({
                        title: 'Share link',
                        body: res.message,
                        buttons: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Dialog.okButton()]
                    });
                }
                else {
                    await promptServerRestart((_a = res.display_name) !== null && _a !== void 0 ? _a : 'the shared folder');
                }
            }
            catch (err) {
                void (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.showErrorMessage)('Could not join share', err instanceof Error ? err.message : String(err));
            }
            finally {
                params.delete(SHARE_LINK_PARAM);
                const newSearch = params.toString();
                const newUrl = window.location.pathname +
                    (newSearch ? `?${newSearch}` : '') +
                    window.location.hash;
                window.history.replaceState({}, '', newUrl);
            }
        };
        void (async () => {
            const me = await (0,_api__WEBPACK_IMPORTED_MODULE_4__.fetchMe)();
            if (me) {
                ownerDomain = me.domain;
                myEmail = me.email;
            }
            await handleShareLink();
            await refreshShares();
        })();
    }
};
// --- Logged-in user indicator in the top-right corner ---
// Renders the user's email as text next to the collaboration avatar.
// Source order: native JupyterLab identity (instant, no network) first,
// then refined via the sharing API's /me (authoritative email) if reachable.
const userIndicator = {
    id: '@jupyterlab-examples/context-menu:user-indicator',
    description: 'Shows the logged-in user email in the top bar.',
    autoStart: true,
    activate: (app) => {
        const node = document.createElement('div');
        node.className = 'jp-UserEmailIndicator';
        const widget = new _lumino_widgets__WEBPACK_IMPORTED_MODULE_3__.Widget({ node });
        widget.id = 'jp-user-email-indicator';
        const setEmail = (email) => {
            if (!email) {
                return;
            }
            node.textContent = email;
            node.title = email;
        };
        // 1. Instant: JupyterLab's own user identity. Under JupyterHub the
        //    username is the SAML `mail` attribute, i.e. the email.
        const userManager = app.serviceManager.user;
        const renderFromIdentity = () => {
            const identity = userManager.identity;
            setEmail((identity === null || identity === void 0 ? void 0 : identity.username) || (identity === null || identity === void 0 ? void 0 : identity.name) || '');
        };
        void userManager.ready.then(renderFromIdentity);
        userManager.userChanged.connect(renderFromIdentity);
        // 2. Authoritative: the sharing API's /me endpoint.
        void (0,_api__WEBPACK_IMPORTED_MODULE_4__.fetchMe)().then(me => {
            if (me === null || me === void 0 ? void 0 : me.email) {
                setEmail(me.email);
            }
        });
        // rank just below the collaboration user menu (1000) so this text
        // sits immediately to the left of the avatar in the right cluster.
        app.shell.add(widget, 'top', { rank: 999 });
    }
};
async function promptServerRestart(folderName) {
    const result = await (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.showDialog)({
        title: 'Restart server to mount shared folder',
        body: `"${folderName}" will appear under /shared/ only after your server restarts — ` +
            `KubeSpawner wires shared volumes at spawn time.\n\n` +
            `Restart now? You'll be taken to the JupyterHub control panel to stop and start ` +
            `your server. Save any unsaved work first.`,
        buttons: [
            _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Dialog.cancelButton({ label: 'Later' }),
            _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Dialog.okButton({ label: 'Open control panel' })
        ]
    });
    if (result.button.accept) {
        const origin = window.location.origin;
        window.location.href = `${origin}/hub/home`;
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ([extension, userIndicator]);


/***/ },

/***/ "./lib/widgets/SharedWithMePanel.js"
/*!******************************************!*\
  !*** ./lib/widgets/SharedWithMePanel.js ***!
  \******************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SharedWithMePanel: () => (/* binding */ SharedWithMePanel)
/* harmony export */ });
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @lumino/signaling */ "webpack/sharing/consume/default/@lumino/signaling");
/* harmony import */ var _lumino_signaling__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_lumino_signaling__WEBPACK_IMPORTED_MODULE_1__);


class SharedWithMePanel extends _lumino_widgets__WEBPACK_IMPORTED_MODULE_0__.Widget {
    constructor() {
        super({ node: document.createElement('div') });
        this._openRequested = new _lumino_signaling__WEBPACK_IMPORTED_MODULE_1__.Signal(this);
        this._refreshRequested = new _lumino_signaling__WEBPACK_IMPORTED_MODULE_1__.Signal(this);
        this.id = 'jlab-shared-with-me';
        this.title.caption = 'Shared with me';
        this.title.iconClass = 'jp-SideBar-tabIcon';
        this.title.label = 'Shared';
        this.addClass('jp-SharedWithMePanel');
        this.node.style.padding = '8px';
        this.node.style.fontSize = '13px';
        this.node.style.overflowY = 'auto';
        const header = document.createElement('div');
        header.style.display = 'flex';
        header.style.justifyContent = 'space-between';
        header.style.alignItems = 'center';
        header.style.marginBottom = '8px';
        const title = document.createElement('strong');
        title.textContent = 'Shared with me';
        this.refreshBtn = document.createElement('button');
        this.refreshBtn.textContent = 'Refresh';
        this.refreshBtn.style.cursor = 'pointer';
        this.refreshBtn.addEventListener('click', () => this._refreshRequested.emit());
        header.appendChild(title);
        header.appendChild(this.refreshBtn);
        this.node.appendChild(header);
        this.statusEl = document.createElement('div');
        this.statusEl.style.color = '#888';
        this.statusEl.style.fontSize = '12px';
        this.statusEl.textContent = 'Loading…';
        this.node.appendChild(this.statusEl);
        this.listEl = document.createElement('ul');
        this.listEl.style.listStyle = 'none';
        this.listEl.style.padding = '0';
        this.listEl.style.margin = '0';
        this.node.appendChild(this.listEl);
    }
    get openRequested() {
        return this._openRequested;
    }
    get refreshRequested() {
        return this._refreshRequested;
    }
    setShares(shares) {
        this.listEl.innerHTML = '';
        const incoming = shares.filter(s => !s.is_owner);
        const owned = shares.filter(s => s.is_owner);
        if (incoming.length === 0 && owned.length === 0) {
            this.statusEl.textContent = 'No shared folders yet.';
            this.statusEl.style.display = 'block';
            return;
        }
        this.statusEl.style.display = 'none';
        if (incoming.length) {
            this.listEl.appendChild(this.renderSectionHeader('From others'));
            for (const s of incoming) {
                this.listEl.appendChild(this.renderItem(s));
            }
        }
        if (owned.length) {
            this.listEl.appendChild(this.renderSectionHeader('Shared by me'));
            for (const s of owned) {
                this.listEl.appendChild(this.renderItem(s));
            }
        }
    }
    setError(message) {
        this.statusEl.textContent = message;
        this.statusEl.style.color = '#e74c3c';
        this.statusEl.style.display = 'block';
        this.listEl.innerHTML = '';
    }
    renderSectionHeader(label) {
        const h = document.createElement('li');
        h.textContent = label;
        h.style.fontSize = '11px';
        h.style.textTransform = 'uppercase';
        h.style.letterSpacing = '0.04em';
        h.style.color = '#666';
        h.style.marginTop = '10px';
        h.style.marginBottom = '4px';
        return h;
    }
    renderItem(share) {
        const li = document.createElement('li');
        li.style.padding = '6px 4px';
        li.style.borderBottom = '1px solid #eee';
        li.style.cursor = 'pointer';
        li.addEventListener('click', () => this._openRequested.emit({ share }));
        const name = document.createElement('div');
        name.textContent = share.display_name;
        name.style.fontWeight = '500';
        const sub = document.createElement('div');
        sub.style.fontSize = '11px';
        sub.style.color = '#666';
        const roleLabel = share.access_level === 'write' ? 'Editor' : 'Viewer';
        if (share.is_owner) {
            const shareState = share.general_access === 'domain'
                ? `shared · domain (${share.link_access_level === 'write' ? 'editor' : 'viewer'})`
                : 'private';
            sub.textContent = `You own · ${shareState}`;
        }
        else {
            const via = share.via === 'domain-link' ? 'via domain link' : 'shared directly';
            sub.textContent = `${roleLabel} · ${share.owner} · ${via}`;
        }
        li.appendChild(name);
        li.appendChild(sub);
        return li;
    }
}


/***/ }

}]);
//# sourceMappingURL=lib_index_js.0ab2048f4e0bdd9175bf.js.map