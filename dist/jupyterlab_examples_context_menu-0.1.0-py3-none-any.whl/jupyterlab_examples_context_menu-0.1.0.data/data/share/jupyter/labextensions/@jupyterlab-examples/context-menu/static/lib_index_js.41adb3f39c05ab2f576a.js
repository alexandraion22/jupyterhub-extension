"use strict";
(self["webpackChunk_jupyterlab_examples_context_menu"] = self["webpackChunk_jupyterlab_examples_context_menu"] || []).push([["lib_index_js"],{

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/filebrowser */ "webpack/sharing/consume/default/@jupyterlab/filebrowser");
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_4__);





const fetchGoogleToken = async () => {
    var _a;
    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_3__.ServerConnection.makeSettings();
    try {
        const response = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_3__.ServerConnection.makeRequest(`${settings.baseUrl}jlab-examples/google-token`, {}, settings);
        if (!response.ok) {
            console.error('Failed to fetch Google token', response.statusText);
            return null;
        }
        const data = (await response.json());
        return (_a = data.token) !== null && _a !== void 0 ? _a : null;
    }
    catch (error) {
        console.error('Error while requesting Google token', error);
        return null;
    }
};
const shareFolder = async (directoryName, shareWithUser, accessRights, token) => {
    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_3__.ServerConnection.makeSettings();
    try {
        const response = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_3__.ServerConnection.makeRequest(`${settings.baseUrl}jlab-examples/share`, {
            method: 'POST',
            body: JSON.stringify({
                directory_name: directoryName,
                share_with_user: shareWithUser,
                access_rights: accessRights,
                token: token
            })
        }, settings);
        if (!response.ok) {
            throw new Error(`Failed to share folder: ${response.statusText}`);
        }
        return await response.json();
    }
    catch (error) {
        console.error('Error sharing folder', error);
        throw error;
    }
};
/**
 * A widget for the share dialog body
 */
class ShareDialogBody extends _lumino_widgets__WEBPACK_IMPORTED_MODULE_4__.Widget {
    constructor() {
        super({ node: document.createElement('div') });
        const emailLabel = document.createElement('label');
        emailLabel.textContent = 'Share with (email):';
        emailLabel.style.display = 'block';
        emailLabel.style.marginBottom = '5px';
        this.emailInput = document.createElement('input');
        this.emailInput.type = 'email';
        this.emailInput.style.width = '100%';
        this.emailInput.style.marginBottom = '15px';
        const rightsLabel = document.createElement('label');
        rightsLabel.textContent = 'Access Rights:';
        rightsLabel.style.display = 'block';
        rightsLabel.style.marginBottom = '5px';
        this.rightsSelect = document.createElement('select');
        this.rightsSelect.style.width = '100%';
        const readOption = document.createElement('option');
        readOption.value = 'read';
        readOption.textContent = 'Read Only';
        readOption.selected = true;
        const writeOption = document.createElement('option');
        writeOption.value = 'write';
        writeOption.textContent = 'Read & Write';
        this.rightsSelect.appendChild(readOption);
        this.rightsSelect.appendChild(writeOption);
        this.node.appendChild(emailLabel);
        this.node.appendChild(this.emailInput);
        this.node.appendChild(rightsLabel);
        this.node.appendChild(this.rightsSelect);
    }
    getValue() {
        return {
            email: this.emailInput.value,
            rights: this.rightsSelect.value
        };
    }
}
const extension = {
    id: '@jupyterlab-examples/context-menu:plugin',
    description: 'A minimal JupyterLab example to develop a context-menu.',
    autoStart: true,
    requires: [_jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_0__.IFileBrowserFactory],
    activate: (app, factory) => {
        const getSelectedItem = () => { var _a, _b; return (_b = (_a = factory.tracker.currentWidget) === null || _a === void 0 ? void 0 : _a.selectedItems().next()) === null || _b === void 0 ? void 0 : _b.value; };
        // Modified to allow sharing any directory, not just root
        const isDirectory = (item) => {
            if (!item) {
                return false;
            }
            return item.type === 'directory';
        };
        app.commands.addCommand('jlab-examples/context-menu:share', {
            label: 'Share Folder',
            caption: "Share this folder with another user",
            icon: _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.buildIcon,
            isEnabled: () => isDirectory(getSelectedItem()),
            isVisible: () => isDirectory(getSelectedItem()),
            execute: async () => {
                const file = getSelectedItem();
                if (!file || !isDirectory(file)) {
                    return;
                }
                // Create the dialog body widget
                const dialogBody = new ShareDialogBody();
                const result = await (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.showDialog)({
                    title: `Share Folder: ${file.name}`,
                    body: dialogBody,
                    buttons: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Dialog.cancelButton(), _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Dialog.okButton({ label: 'Share' })]
                });
                if (result.button.accept) {
                    const { email, rights } = dialogBody.getValue();
                    if (!email) {
                        void (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.showErrorMessage)('Error', 'Email is required.');
                        return;
                    }
                    try {
                        const token = await fetchGoogleToken();
                        // Even if token is null, we might want to proceed? 
                        // The user said "send the auth token", implying it's required.
                        // If token is missing, we can send empty string or fail.
                        await shareFolder(file.name, email, rights, token || '');
                        void (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.showDialog)({
                            title: 'Success',
                            body: `Successfully shared folder "${file.name}" with ${email}.`,
                            buttons: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Dialog.okButton()]
                        });
                    }
                    catch (error) {
                        void (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.showErrorMessage)('Sharing Failed', error instanceof Error ? error.message : String(error));
                    }
                }
            }
        });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (extension);


/***/ })

}]);
//# sourceMappingURL=lib_index_js.41adb3f39c05ab2f576a.js.map