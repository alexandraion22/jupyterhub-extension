"use strict";
(self["webpackChunk_jupyterlab_examples_context_menu"] = self["webpackChunk_jupyterlab_examples_context_menu"] || []).push([["lib_index_js"],{

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/filebrowser */ "webpack/sharing/consume/default/@jupyterlab/filebrowser");
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_4__);





class ShareForm extends _lumino_widgets__WEBPACK_IMPORTED_MODULE_4__.Widget {
    constructor() {
        super({ node: document.createElement('div') });
        this.addClass('jp-ShareForm');
        const emailLabel = document.createElement('label');
        emailLabel.textContent = 'User Email:';
        emailLabel.style.display = 'block';
        emailLabel.style.marginBottom = '5px';
        const emailInput = document.createElement('input');
        emailInput.type = 'email';
        emailInput.placeholder = 'user@example.com';
        emailInput.style.width = '100%';
        emailInput.style.marginBottom = '15px';
        this.emailNode = emailInput;
        const accessLabel = document.createElement('label');
        accessLabel.textContent = 'Access Level:';
        accessLabel.style.display = 'block';
        accessLabel.style.marginBottom = '5px';
        const accessSelect = document.createElement('select');
        accessSelect.style.width = '100%';
        const readOption = document.createElement('option');
        readOption.value = 'read';
        readOption.textContent = 'Read Only';
        const writeOption = document.createElement('option');
        writeOption.value = 'write';
        writeOption.textContent = 'Read & Write';
        accessSelect.appendChild(readOption);
        accessSelect.appendChild(writeOption);
        this.accessNode = accessSelect;
        this.node.appendChild(emailLabel);
        this.node.appendChild(emailInput);
        this.node.appendChild(accessLabel);
        this.node.appendChild(accessSelect);
    }
    getValue() {
        return {
            target_email: this.emailNode.value,
            access_level: this.accessNode.value
        };
    }
}
// Removed unused fetchGoogleToken
const shareVolume = async (volumeName, targetEmail, accessLevel) => {
    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_3__.ServerConnection.makeSettings();
    try {
        const response = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_3__.ServerConnection.makeRequest(`${settings.baseUrl}jlab-examples/share`, {
            method: 'POST',
            body: JSON.stringify({
                volume_name: volumeName,
                target_email: targetEmail,
                access_level: accessLevel
            })
        }, settings);
        if (!response.ok) {
            const data = await response.json();
            throw new Error(data.error || response.statusText);
        }
        await (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.showDialog)({
            title: 'Success',
            body: `Successfully shared ${volumeName} with ${targetEmail}`,
            buttons: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Dialog.okButton()]
        });
    }
    catch (error) {
        console.error('Error sharing volume', error);
        await (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.showDialog)({
            title: 'Error',
            body: `Failed to share volume: ${error.message || error}`,
            buttons: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Dialog.okButton()]
        });
    }
};
const extension = {
    id: '@jupyterlab-examples/context-menu:plugin',
    description: 'Context menu to share volumes.',
    autoStart: true,
    requires: [_jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_0__.IFileBrowserFactory],
    activate: (app, factory) => {
        const getSelectedItem = () => { var _a, _b; return (_b = (_a = factory.tracker.currentWidget) === null || _a === void 0 ? void 0 : _a.selectedItems().next()) === null || _b === void 0 ? void 0 : _b.value; };
        const isRootDirectory = (item) => {
            if (!item) {
                return false;
            }
            return item.type === 'directory' && !item.path.includes('/');
        };
        app.commands.addCommand('jlab-examples/context-menu:open', {
            label: 'Share Volume',
            caption: "Share this volume with another user",
            icon: _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.buildIcon,
            isEnabled: () => isRootDirectory(getSelectedItem()),
            isVisible: () => isRootDirectory(getSelectedItem()),
            execute: async () => {
                const file = getSelectedItem();
                if (!file || !isRootDirectory(file)) {
                    return;
                }
                const dialogBody = new ShareForm();
                const result = await (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.showDialog)({
                    title: `Share Volume: ${file.name}`,
                    body: dialogBody,
                    buttons: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Dialog.cancelButton(), _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Dialog.okButton({ label: 'Share' })]
                });
                if (result.button.accept) {
                    const formData = dialogBody.getValue();
                    if (!formData.target_email) {
                        await (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.showDialog)({
                            title: 'Error',
                            body: 'Email is required.',
                            buttons: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Dialog.okButton()]
                        });
                        return;
                    }
                    await shareVolume(file.name, formData.target_email, formData.access_level);
                }
            }
        });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (extension);


/***/ })

}]);
//# sourceMappingURL=lib_index_js.2bfe4196bd00895ea623.js.map