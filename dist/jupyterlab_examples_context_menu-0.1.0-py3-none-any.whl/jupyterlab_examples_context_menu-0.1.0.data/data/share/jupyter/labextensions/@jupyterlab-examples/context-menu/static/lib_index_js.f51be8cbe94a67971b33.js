"use strict";
(self["webpackChunk_jupyterlab_examples_context_menu"] = self["webpackChunk_jupyterlab_examples_context_menu"] || []).push([["lib_index_js"],{

/***/ "./lib/api.js":
/*!********************!*\
  !*** ./lib/api.js ***!
  \********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fetchApiToken: () => (/* binding */ fetchApiToken),
/* harmony export */   fetchPermissions: () => (/* binding */ fetchPermissions),
/* harmony export */   revokeAccess: () => (/* binding */ revokeAccess),
/* harmony export */   shareFolder: () => (/* binding */ shareFolder)
/* harmony export */ });
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_0__);

const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_0__.ServerConnection.makeSettings();
const fetchApiToken = async () => {
    var _a;
    try {
        const response = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_0__.ServerConnection.makeRequest(`${settings.baseUrl}jlab-examples/google-token`, {}, settings);
        if (!response.ok) {
            console.error('Failed to fetch API token:', response.statusText);
            return null;
        }
        const data = (await response.json());
        return (_a = data.token) !== null && _a !== void 0 ? _a : null;
    }
    catch (error) {
        console.error('Error fetching API token:', error);
        return null;
    }
};
const shareFolder = async (directoryName, shareWithUser, accessRights, token) => {
    var _a;
    const response = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_0__.ServerConnection.makeRequest(`${settings.baseUrl}jlab-examples/share`, {
        method: 'POST',
        body: JSON.stringify({
            directory_name: directoryName,
            share_with_user: shareWithUser,
            access_rights: accessRights,
            token: token
        })
    }, settings);
    const data = await response.json();
    if (!response.ok) {
        const msg = ((_a = data === null || data === void 0 ? void 0 : data.error) === null || _a === void 0 ? void 0 : _a.message) || (data === null || data === void 0 ? void 0 : data.error) || response.statusText;
        throw new Error(msg);
    }
    return data;
};
const fetchPermissions = async (directoryName, token) => {
    var _a;
    const response = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_0__.ServerConnection.makeRequest(`${settings.baseUrl}jlab-examples/permissions?directory=${encodeURIComponent(directoryName)}`, {
        method: 'GET',
        headers: { 'Authorization': `Bearer ${token}` }
    }, settings);
    const data = await response.json();
    if (!response.ok) {
        const msg = ((_a = data === null || data === void 0 ? void 0 : data.error) === null || _a === void 0 ? void 0 : _a.message) || (data === null || data === void 0 ? void 0 : data.error) || response.statusText;
        throw new Error(msg);
    }
    return data;
};
const revokeAccess = async (volumeName, userEmail, token) => {
    var _a;
    const response = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_0__.ServerConnection.makeRequest(`${settings.baseUrl}jlab-examples/permissions`, {
        method: 'DELETE',
        body: JSON.stringify({
            volume_name: volumeName,
            user_email: userEmail,
            token: token
        })
    }, settings);
    const data = await response.json();
    if (!response.ok) {
        const msg = ((_a = data === null || data === void 0 ? void 0 : data.error) === null || _a === void 0 ? void 0 : _a.message) || (data === null || data === void 0 ? void 0 : data.error) || response.statusText;
        throw new Error(msg);
    }
    return data;
};


/***/ }),

/***/ "./lib/dialogs/PermissionsDialog.js":
/*!******************************************!*\
  !*** ./lib/dialogs/PermissionsDialog.js ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PermissionsDialogBody: () => (/* binding */ PermissionsDialogBody)
/* harmony export */ });
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_0__);

class PermissionsDialogBody extends _lumino_widgets__WEBPACK_IMPORTED_MODULE_0__.Widget {
    constructor() {
        super({ node: document.createElement('div') });
        this._onRevoke = null;
        this.node.style.minWidth = '400px';
        this.statusDiv = document.createElement('div');
        this.statusDiv.textContent = 'Loading permissions...';
        this.statusDiv.style.padding = '10px 0';
        this.node.appendChild(this.statusDiv);
        const table = document.createElement('table');
        table.style.width = '100%';
        table.style.borderCollapse = 'collapse';
        table.style.display = 'none';
        const thead = document.createElement('thead');
        const headerRow = document.createElement('tr');
        for (const text of ['Email', 'Access', 'Actions']) {
            const th = document.createElement('th');
            th.textContent = text;
            th.style.textAlign = 'left';
            th.style.padding = '6px 8px';
            th.style.borderBottom = '2px solid #ddd';
            headerRow.appendChild(th);
        }
        thead.appendChild(headerRow);
        table.appendChild(thead);
        this.tableBody = document.createElement('tbody');
        table.appendChild(this.tableBody);
        this.node.appendChild(table);
    }
    set onRevoke(handler) {
        this._onRevoke = handler;
    }
    setPermissions(permissions, ownerEmail) {
        this.statusDiv.style.display = 'none';
        const table = this.node.querySelector('table');
        table.style.display = 'table';
        this.tableBody.innerHTML = '';
        if (permissions.length === 0) {
            this.statusDiv.textContent = 'No permissions found.';
            this.statusDiv.style.display = 'block';
            table.style.display = 'none';
            return;
        }
        for (const perm of permissions) {
            const row = document.createElement('tr');
            const isOwner = perm.user_email === ownerEmail;
            const emailCell = document.createElement('td');
            emailCell.textContent = perm.user_email + (isOwner ? ' (owner)' : '');
            emailCell.style.padding = '6px 8px';
            emailCell.style.borderBottom = '1px solid #eee';
            const accessCell = document.createElement('td');
            accessCell.textContent = perm.access_level;
            accessCell.style.padding = '6px 8px';
            accessCell.style.borderBottom = '1px solid #eee';
            const actionCell = document.createElement('td');
            actionCell.style.padding = '6px 8px';
            actionCell.style.borderBottom = '1px solid #eee';
            if (!isOwner) {
                const revokeBtn = document.createElement('button');
                revokeBtn.textContent = 'Revoke';
                revokeBtn.style.cursor = 'pointer';
                revokeBtn.style.padding = '2px 8px';
                revokeBtn.addEventListener('click', async () => {
                    if (this._onRevoke) {
                        revokeBtn.textContent = 'Revoking...';
                        revokeBtn.disabled = true;
                        try {
                            await this._onRevoke(perm.user_email);
                            row.remove();
                        }
                        catch (err) {
                            revokeBtn.textContent = 'Failed';
                            setTimeout(() => {
                                revokeBtn.textContent = 'Revoke';
                                revokeBtn.disabled = false;
                            }, 2000);
                        }
                    }
                });
                actionCell.appendChild(revokeBtn);
            }
            row.appendChild(emailCell);
            row.appendChild(accessCell);
            row.appendChild(actionCell);
            this.tableBody.appendChild(row);
        }
    }
    setError(message) {
        this.statusDiv.textContent = message;
        this.statusDiv.style.display = 'block';
        this.statusDiv.style.color = '#e74c3c';
        const table = this.node.querySelector('table');
        table.style.display = 'none';
    }
}


/***/ }),

/***/ "./lib/dialogs/ShareDialog.js":
/*!************************************!*\
  !*** ./lib/dialogs/ShareDialog.js ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ShareDialogBody: () => (/* binding */ ShareDialogBody)
/* harmony export */ });
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_0__);

const EMAIL_RE = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
class ShareDialogBody extends _lumino_widgets__WEBPACK_IMPORTED_MODULE_0__.Widget {
    constructor() {
        super({ node: document.createElement('div') });
        const emailLabel = document.createElement('label');
        emailLabel.textContent = 'Share with (email):';
        emailLabel.style.display = 'block';
        emailLabel.style.marginBottom = '5px';
        this.emailInput = document.createElement('input');
        this.emailInput.type = 'email';
        this.emailInput.placeholder = 'user@example.com';
        this.emailInput.style.width = '100%';
        this.emailInput.style.marginBottom = '5px';
        this.errorSpan = document.createElement('span');
        this.errorSpan.style.color = '#e74c3c';
        this.errorSpan.style.fontSize = '12px';
        this.errorSpan.style.display = 'none';
        this.errorSpan.style.marginBottom = '10px';
        const rightsLabel = document.createElement('label');
        rightsLabel.textContent = 'Access Rights:';
        rightsLabel.style.display = 'block';
        rightsLabel.style.marginBottom = '5px';
        rightsLabel.style.marginTop = '10px';
        this.rightsSelect = document.createElement('select');
        this.rightsSelect.style.width = '100%';
        const readOption = document.createElement('option');
        readOption.value = 'read';
        readOption.textContent = 'Read Only';
        readOption.selected = true;
        const writeOption = document.createElement('option');
        writeOption.value = 'write';
        writeOption.textContent = 'Read & Write';
        this.rightsSelect.appendChild(readOption);
        this.rightsSelect.appendChild(writeOption);
        this.node.appendChild(emailLabel);
        this.node.appendChild(this.emailInput);
        this.node.appendChild(this.errorSpan);
        this.node.appendChild(rightsLabel);
        this.node.appendChild(this.rightsSelect);
    }
    validate() {
        const email = this.emailInput.value.trim();
        if (!email) {
            this.showError('Email is required.');
            return false;
        }
        if (!EMAIL_RE.test(email)) {
            this.showError('Please enter a valid email address.');
            return false;
        }
        this.hideError();
        return true;
    }
    getValue() {
        return {
            email: this.emailInput.value.trim(),
            rights: this.rightsSelect.value
        };
    }
    showError(msg) {
        this.errorSpan.textContent = msg;
        this.errorSpan.style.display = 'block';
    }
    hideError() {
        this.errorSpan.style.display = 'none';
    }
}


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/filebrowser */ "webpack/sharing/consume/default/@jupyterlab/filebrowser");
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./api */ "./lib/api.js");
/* harmony import */ var _dialogs_ShareDialog__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./dialogs/ShareDialog */ "./lib/dialogs/ShareDialog.js");
/* harmony import */ var _dialogs_PermissionsDialog__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./dialogs/PermissionsDialog */ "./lib/dialogs/PermissionsDialog.js");






const extension = {
    id: '@jupyterlab-examples/context-menu:plugin',
    description: 'JupyterLab extension for folder sharing and permissions management.',
    autoStart: true,
    requires: [_jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_0__.IFileBrowserFactory],
    activate: (app, factory) => {
        const getSelectedItem = () => { var _a, _b; return (_b = (_a = factory.tracker.currentWidget) === null || _a === void 0 ? void 0 : _a.selectedItems().next()) === null || _b === void 0 ? void 0 : _b.value; };
        const isDirectory = (item) => (item === null || item === void 0 ? void 0 : item.type) === 'directory';
        // --- Share Folder command ---
        app.commands.addCommand('jlab-examples/context-menu:share', {
            label: 'Share Folder',
            caption: 'Share this folder with another user',
            icon: _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.buildIcon,
            isEnabled: () => isDirectory(getSelectedItem()),
            isVisible: () => isDirectory(getSelectedItem()),
            execute: async () => {
                const file = getSelectedItem();
                if (!file || !isDirectory(file)) {
                    return;
                }
                const dialogBody = new _dialogs_ShareDialog__WEBPACK_IMPORTED_MODULE_4__.ShareDialogBody();
                const result = await (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.showDialog)({
                    title: `Share Folder: ${file.name}`,
                    body: dialogBody,
                    buttons: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Dialog.cancelButton(), _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Dialog.okButton({ label: 'Share' })]
                });
                if (result.button.accept) {
                    if (!dialogBody.validate()) {
                        return;
                    }
                    const { email, rights } = dialogBody.getValue();
                    try {
                        const token = await (0,_api__WEBPACK_IMPORTED_MODULE_3__.fetchApiToken)();
                        if (!token) {
                            void (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.showErrorMessage)('Authentication Error', 'Session expired or token unavailable. Please restart your server.');
                            return;
                        }
                        await (0,_api__WEBPACK_IMPORTED_MODULE_3__.shareFolder)(file.name, email, rights, token);
                        void (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.showDialog)({
                            title: 'Success',
                            body: `Successfully shared folder "${file.name}" with ${email}.`,
                            buttons: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Dialog.okButton()]
                        });
                    }
                    catch (error) {
                        void (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.showErrorMessage)('Sharing Failed', error instanceof Error ? error.message : String(error));
                    }
                }
            }
        });
        // --- View Permissions command ---
        app.commands.addCommand('jlab-examples/context-menu:view-permissions', {
            label: 'View Permissions',
            caption: 'View who has access to this folder',
            icon: _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_2__.buildIcon,
            isEnabled: () => isDirectory(getSelectedItem()),
            isVisible: () => isDirectory(getSelectedItem()),
            execute: async () => {
                const file = getSelectedItem();
                if (!file || !isDirectory(file)) {
                    return;
                }
                const token = await (0,_api__WEBPACK_IMPORTED_MODULE_3__.fetchApiToken)();
                if (!token) {
                    void (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.showErrorMessage)('Authentication Error', 'Session expired or token unavailable. Please restart your server.');
                    return;
                }
                const dialogBody = new _dialogs_PermissionsDialog__WEBPACK_IMPORTED_MODULE_5__.PermissionsDialogBody();
                // Load permissions asynchronously
                (0,_api__WEBPACK_IMPORTED_MODULE_3__.fetchPermissions)(file.name, token)
                    .then(data => {
                    dialogBody.setPermissions(data.permissions, data.owner);
                    dialogBody.onRevoke = async (userEmail) => {
                        await (0,_api__WEBPACK_IMPORTED_MODULE_3__.revokeAccess)(data.volume_name, userEmail, token);
                    };
                })
                    .catch(err => {
                    const msg = err instanceof Error ? err.message : 'Failed to load permissions';
                    dialogBody.setError(msg);
                });
                await (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.showDialog)({
                    title: `Permissions: ${file.name}`,
                    body: dialogBody,
                    buttons: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.Dialog.okButton({ label: 'Close' })]
                });
            }
        });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (extension);


/***/ })

}]);
//# sourceMappingURL=lib_index_js.f51be8cbe94a67971b33.js.map